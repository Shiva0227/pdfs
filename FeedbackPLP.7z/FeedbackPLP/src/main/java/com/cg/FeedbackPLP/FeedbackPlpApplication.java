package com.cg.FeedbackPLP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedbackPlpApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedbackPlpApplication.class, args);
	}

}
