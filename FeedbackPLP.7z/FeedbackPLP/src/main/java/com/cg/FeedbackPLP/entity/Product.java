package com.cg.FeedbackPLP.entity;

public class Product {
private int product_Id;
private String product_Name;
private int product_Quantity;
private int product_price;
private String Product_Description;
private int Product_Rating;
private String category_Name;
private String product_Band;
private String image;
private int discount;
private int merchant_id;
public Product() {
	super();
	// TODO Auto-generated constructor stub
}
public Product(int product_Id, String product_Name, int product_Quantity, int product_price, String product_Description,
		int product_Rating, String category_Name, String product_Band, String image, int discount, int merchant_id) {
	super();
	this.product_Id = product_Id;
	this.product_Name = product_Name;
	this.product_Quantity = product_Quantity;
	this.product_price = product_price;
	Product_Description = product_Description;
	Product_Rating = product_Rating;
	this.category_Name = category_Name;
	this.product_Band = product_Band;
	this.image = image;
	this.discount = discount;
	this.merchant_id = merchant_id;
}
public int getProduct_Id() {
	return product_Id;
}
public void setProduct_Id(int product_Id) {
	this.product_Id = product_Id;
}
public String getProduct_Name() {
	return product_Name;
}
public void setProduct_Name(String product_Name) {
	this.product_Name = product_Name;
}
public int getProduct_Quantity() {
	return product_Quantity;
}
public void setProduct_Quantity(int product_Quantity) {
	this.product_Quantity = product_Quantity;
}
public int getProduct_price() {
	return product_price;
}
public void setProduct_price(int product_price) {
	this.product_price = product_price;
}
public String getProduct_Description() {
	return Product_Description;
}
public void setProduct_Description(String product_Description) {
	Product_Description = product_Description;
}
public int getProduct_Rating() {
	return Product_Rating;
}
public void setProduct_Rating(int product_Rating) {
	Product_Rating = product_Rating;
}
public String getCategory_Name() {
	return category_Name;
}
public void setCategory_Name(String category_Name) {
	this.category_Name = category_Name;
}
public String getProduct_Band() {
	return product_Band;
}
public void setProduct_Band(String product_Band) {
	this.product_Band = product_Band;
}
public String getImage() {
	return image;
}
public void setImage(String image) {
	this.image = image;
}
public int getDiscount() {
	return discount;
}
public void setDiscount(int discount) {
	this.discount = discount;
}
public int getMerchant_id() {
	return merchant_id;
}
public void setMerchant_id(int merchant_id) {
	this.merchant_id = merchant_id;
}
@Override
public String toString() {
	return "Product [product_Id=" + product_Id + ", product_Name=" + product_Name + ", product_Quantity="
			+ product_Quantity + ", product_price=" + product_price + ", Product_Description=" + Product_Description
			+ ", Product_Rating=" + Product_Rating + ", category_Name=" + category_Name + ", product_Band="
			+ product_Band + ", image=" + image + ", discount=" + discount + ", merchant_id=" + merchant_id + "]";
}


}
