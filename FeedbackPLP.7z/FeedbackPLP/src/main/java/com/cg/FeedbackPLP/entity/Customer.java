package com.cg.FeedbackPLP.entity;

public class Customer {
	private int customerId;
	private String contactNo;
	private String Name;
	private String email;
	private String password;
	private String Question;
	private String answer;
	private String balance;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(int customerId, String contactNo, String name, String email, String password, String question,
			String answer, String balance) {
		super();
		this.customerId = customerId;
		this.contactNo = contactNo;
		Name = name;
		this.email = email;
		this.password = password;
		Question = question;
		this.answer = answer;
		this.balance = balance;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String question) {
		Question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", contactNo=" + contactNo + ", Name=" + Name + ", email=" + email
				+ ", password=" + password + ", Question=" + Question + ", answer=" + answer + ", balance=" + balance
				+ "]";
	}
	
	
	

}
