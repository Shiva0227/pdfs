package com.cg.FeedbackPLP.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="feedback")
public class FeedBack {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int feedback_id;
	@Column(name = "feedback")
	private String feedback;
	@Column(name = "cust_id")
	private Customer customerid;
	@Column(name = "product_id")
	private Product product_id;
	public FeedBack() {
		super();
		// TODO Auto-generated constructor stub
	}
	public FeedBack(int feedback_id, String feedback, Customer customerid, Product product_id) {
		super();
		this.feedback_id = feedback_id;
		this.feedback = feedback;
		this.customerid = customerid;
		this.product_id = product_id;
	}
	public int getFeedback_id() {
		return feedback_id;
	}
	public void setFeedback_id(int feedback_id) {
		this.feedback_id = feedback_id;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public Customer getCustomerid() {
		return customerid;
	}
	public void setCustomerid(Customer customerid) {
		this.customerid = customerid;
	}
	public Product getProduct_id() {
		return product_id;
	}
	public void setProduct_id(Product product_id) {
		this.product_id = product_id;
	}
	@Override
	public String toString() {
		return "product [feedback_id=" + feedback_id + ", feedback=" + feedback + ", customerid=" + customerid
				+ ", product_id=" + product_id + "]";
	}
	
	
	
}
