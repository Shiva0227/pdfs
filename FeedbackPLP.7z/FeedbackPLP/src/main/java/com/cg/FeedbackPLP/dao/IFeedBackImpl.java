package com.cg.FeedbackPLP.dao;

public class IFeedBackImpl {

}
